extern char AuthKeyTable[512][2][128];
