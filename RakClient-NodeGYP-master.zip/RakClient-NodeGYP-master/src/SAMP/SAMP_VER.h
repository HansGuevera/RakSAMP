//this file only defines samp version
#define SAMP_037